<script setup lang="ts">
defineProps({
  size: {
    type: Number,
    default: 40,
  },
  color: {
    type: String,
    default: 'cta',
  },
});
</script>

<template>
  <svg
    :class="`text-${color}`"
    :width="size"
    :height="size"
    viewBox="0 0 24 24"
    fill="none"
  >
    <path
      fill-rule="evenodd"
      clip-rule="evenodd"
      d="M3.75 5.25 3 6v12l.75.75h16.5L21 18V6l-.75-.75zm.75 2.446v9.554h15V7.695L12 14.514zm13.81-.946H5.69L12 12.486z"
      fill="currentColor"
    />
  </svg>
</template>

<style scoped></style>
